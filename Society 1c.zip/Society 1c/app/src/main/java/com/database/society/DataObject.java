package com.database.society;

public class DataObject {
    private String unit_nos;
    public DataObject(){}
    public DataObject(String name) {
        this.unit_nos = unit_nos;
    }
    public String getUnitno() {
        return unit_nos;
    }
    public void setUnitno(String unit_nos) {
        this.unit_nos = unit_nos;
    }
}