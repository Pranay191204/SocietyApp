package com.database.society;

public class SpinnerAdapter {
}
